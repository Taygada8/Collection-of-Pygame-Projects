# actor_control.py
from panda3d.core import Point3
from direct.actor.Actor import Actor
from direct.interval.IntervalGlobal import Sequence

class Panda:
    def __init__(self, render):
        # Load the Panda actor
        self.pandaActor = Actor("models/panda-model", {"walk": "models/panda-walk4"})
        self.pandaActor.setScale(0.005, 0.005, 0.005)
        self.pandaActor.reparentTo(render)
        self.pandaActor.loop("walk")  # Start the walk animation by default

        # Create movement intervals for the pandaActor
        self.create_panda_movement()

    def create_panda_movement(self):
        # Create the movement intervals for the panda to walk back and forth
        posInterval1 = self.pandaActor.posInterval(13, Point3(0, -10, 0), startPos=Point3(0, 10, 0))
        posInterval2 = self.pandaActor.posInterval(13, Point3(0, 10, 0), startPos=Point3(0, -10, 0))
        hprInterval1 = self.pandaActor.hprInterval(3, Point3(180, 0, 0), startHpr=Point3(0, 0, 0))
        hprInterval2 = self.pandaActor.hprInterval(3, Point3(0, 0, 0), startHpr=Point3(180, 0, 0))

        # Create and play the sequence that coordinates the intervals
        self.pandaPace = Sequence(posInterval1, hprInterval1, posInterval2, hprInterval2, name="pandaPace")
        self.pandaPace.loop()

    def start_animation(self):
        # Start the walk animation if it's not already playing
        if not self.pandaActor.getCurrentAnim():
            self.pandaActor.loop("walk")

    def stop_animation(self):
        # Stop the walk animation
        self.pandaActor.stop()
