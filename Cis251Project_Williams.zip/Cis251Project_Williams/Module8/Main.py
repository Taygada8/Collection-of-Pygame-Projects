# Moduled project with additonal actors Collision , Panda, Discohall, Animated lights , Userinterface , along with music audio
# CIS 251
# Marquis Williams
#Shows print message with Gltf files imported will revise and update the size of the files
#updated with fox actor alognside panda 

# --- Panda3D Configuration ---
from panda3d.core import loadPrcFileData
loadPrcFileData("", "audio-library-name p3openal_audio")
loadPrcFileData("", "audio-active true")
loadPrcFileData("", "load-file-type p3assimp")  # Enable GLTF/GLB with Assimp

from panda3d.core import (
    Point3, DirectionalLight, AmbientLight, Spotlight, NodePath,
    LVector3, PerspectiveLens, TextNode, PointLight
)
from direct.showbase.ShowBase import ShowBase
from direct.task import Task
from direct.gui.OnscreenText import OnscreenText
import sys
import os
import math

from key_map import KeyMap
from actor_control import ActorControl
from camera import CameraControl
from UI_Elements import UserInterface


class MyApp(ShowBase):
    def __init__(self):
        ShowBase.__init__(self)
        self.disableMouse()

        # Initialize key map
        self.keyMap = KeyMap()

        # Load the disco hall model
        self.disco = self.loader.loadModel("models/disco_hall")
        self.disco.reparentTo(self.render)
        self.disco.setPosHpr(0, 50, -4, 90, 0, 0)

        # Score display
        self.score = 0
        self.score_text = OnscreenText(
            text=f"Score: {self.score}",
            pos=(-1.3, 0.9), scale=0.08, fg=(1, 1, 0, 1), align=TextNode.ALeft, mayChange=True
        )

        # Initialize actor control
        self.actorControl = ActorControl(self, self.render, score_callback=self.update_score)

        # Collision task
        def traverse_collisions(task):
            self.actorControl.collision_traverser.traverse(self.render)
            return Task.cont
        self.taskMgr.add(traverse_collisions, "traverseCollisions")

        # Initialize camera control
        self.cameraControl = CameraControl(self, self.actorControl.pandaActor)
        self.taskMgr.add(self.manageCameraTasks, "manageCameraTasks")

        # Key bindings
        self.accept('w', self.keyMap.set_key, ['startAnimation', True])
        self.accept('w-up', self.keyMap.set_key, ['startAnimation', False])
        self.accept('s', self.keyMap.set_key, ['stopAnimation', True])
        self.accept('s-up', self.keyMap.set_key, ['stopAnimation', False])
        self.accept('1', self.setCameraSpin)
        self.accept('2', self.setCameraFollow)
        self.accept('3', self.setFirstPersonView)

        # Lights
        self.setup_lights()
        self.add_lights()
        self.taskMgr.add(self.animate_lights, "animateLights")

        # UI
        self.userInterface = UserInterface(
            self, self.spotlight, self.directionalLight, self.toggle_shadows,
            reset_callback=self.reset_panda,
            quit_callback=self.quit_app
        )

        # --- Audio (OpenAL) ---
        self.init_audio()

        # --- GLTF Object Imports Added ---
        self.load_gltf_models()

    def load_gltf_models(self):
        """Load GLTF/GLB models into the scene."""
        # Load and display Duck.glb
        duck_path = "Duck.glb"
        if os.path.exists(duck_path):
            try:
                self.duck_model = self.loader.loadModel(duck_path)
                self.duck_model.reparentTo(self.render)
                self.duck_model.setPos(0, 10, 0)   # In front of the camera
                self.duck_model.setScale(0.5)
                print("Loaded Duck.glb")
            except Exception as e:
                print(f"Failed to load Duck.glb: {e}")
        else:
            print(f"Duck.glb not found in {os.getcwd()}")

        # Load and display Table.glb
        table_path = "Table.glb"
        if os.path.exists(table_path):
            try:
                self.table_model = self.loader.loadModel(table_path)
                self.table_model.reparentTo(self.render)
                self.table_model.setPos(2, 12, 0)  # Slightly to the right and farther
                self.table_model.setScale(20.0)
                print("Loaded Table.glb")
            except Exception as e:
                print(f"Failed to load Table.glb: {e}")
        else:
            print(f"Table.glb not found in {os.getcwd()}")

        # Load and display Fox.glb
        fox_path = "Fox.glb"
        if os.path.exists(fox_path):
            try:
                self.fox_model = self.loader.loadModel(fox_path)
                self.fox_model.reparentTo(self.render)
                self.fox_model.setPos(-3, 8, 0)  # Slightly to the left
                self.fox_model.setScale(0.090)   # Scale down the Fox model
                print("Loaded Fox.glb")
            except Exception as e:
                print(f"Failed to load Fox.glb: {e}")
        else:
            print(f"Fox.glb not found in {os.getcwd()}")

        print("✅ Successfully loaded and displayed GLTF models (Duck, Table & Fox) on stage.")

    # --- Score/UI methods ---
    def update_score(self, new_score):
        self.score = new_score
        self.score_text.setText(f"Score: {self.score}")

    def reset_panda(self):
        self.actorControl.reset_panda()

    def quit_app(self):
        sys.exit(0)

    # --- Lights ---
    def setup_lights(self):
        self.ambientLight = self.render.attachNewNode(AmbientLight("ambientLight"))
        self.ambientLight.node().setColor((.1, .1, .1, 1))

        self.directionalLight = self.render.attachNewNode(DirectionalLight("directionalLight"))
        self.directionalLight.node().setColor((.35, .35, .35, 1))
        self.directionalLight.node().setDirection(LVector3(1, 1, -2))

        self.spotlight = self.camera.attachNewNode(Spotlight("spotlight"))
        self.spotlight.node().setColor((.45, .45, .45, 1))
        self.spotlight.node().setSpecularColor((0, 0, 0, 1))
        self.spotlight.node().setLens(PerspectiveLens())
        self.spotlight.node().getLens().setFov(16, 16)
        self.spotlight.node().setAttenuation(LVector3(1, 0.0, 0.0))
        self.spotlight.node().setExponent(60.0)
        self.spotlight.node().setShadowCaster(False)

        self.redHelper = self.loader.loadModel('models/sphere')
        self.redHelper.setColor((1, 0, 0, 1))
        self.redHelper.setPos(-6.5, -3.75, 0)
        self.redHelper.setScale(.25)
        self.redPointLight = self.redHelper.attachNewNode(PointLight("redPointLight"))
        self.redPointLight.node().setColor((.35, 0, 0, 1))
        self.redPointLight.node().setAttenuation(LVector3(.1, 0.04, 0.0))

        self.greenHelper = self.loader.loadModel('models/sphere')
        self.greenHelper.setColor((0, 1, 0, 1))
        self.greenHelper.setPos(0, 7.5, 0)
        self.greenHelper.setScale(.25)
        self.greenPointLight = self.greenHelper.attachNewNode(PointLight("greenPointLight"))
        self.greenPointLight.node().setColor((0, .35, 0, 1))
        self.greenPointLight.node().setAttenuation(LVector3(.1, .04, .0))

        self.blueHelper = self.loader.loadModel('models/sphere')
        self.blueHelper.setColor((0, 0, 1, 1))
        self.blueHelper.setPos(6.5, -3.75, 0)
        self.blueHelper.setScale(.25)
        self.bluePointLight = self.blueHelper.attachNewNode(PointLight("bluePointLight"))
        self.bluePointLight.node().setColor((0, 0, .35, 1))
        self.bluePointLight.node().setAttenuation(LVector3(.1, 0.04, .0))

    def add_lights(self):
        self.render.setLight(self.ambientLight)
        self.render.setLight(self.directionalLight)
        self.render.setLight(self.spotlight)
        self.render.setLight(self.redPointLight)
        self.render.setLight(self.greenPointLight)
        self.render.setLight(self.bluePointLight)

        self.pointLightHelper = self.render.attachNewNode("pointLightHelper")
        self.pointLightHelper.setPos(0, 50, 11)
        self.redHelper.reparentTo(self.pointLightHelper)
        self.greenHelper.reparentTo(self.pointLightHelper)
        self.blueHelper.reparentTo(self.pointLightHelper)

        self.pointLightsSpin = self.pointLightHelper.hprInterval(6, LVector3(360, 0, 0))
        self.pointLightsSpin.loop()

    def animate_lights(self, task):
        t = task.time
        redColor = (0.35 + 0.35 * math.sin(t * 1.5), 0, 0, 1)
        greenColor = (0, 0.35 + 0.35 * math.cos(t * 1.5), 0, 1)
        blueColor = (0, 0, 0.35 + 0.35 * math.sin(t * 1.5), 1)
        self.redPointLight.node().setColor(redColor)
        self.greenPointLight.node().setColor(greenColor)
        self.bluePointLight.node().setColor(blueColor)
        return Task.cont

    # --- Camera ---
    def manageCameraTasks(self, task):
        if self.keyMap.get_key('startAnimation'):
            self.actorControl.start_animation()
        if self.keyMap.get_key('stopAnimation'):
            self.actorControl.stop_animation()
        return Task.cont

    def setCameraSpin(self):
        self.taskMgr.remove('followCameraTask')
        self.taskMgr.remove('firstPersonViewTask')
        self.taskMgr.add(self.cameraControl.spin_camera_task, "spinCameraTask")

    def setCameraFollow(self):
        self.taskMgr.remove('spinCameraTask')
        self.taskMgr.remove('firstPersonViewTask')
        self.taskMgr.add(self.cameraControl.follow_camera_task, "followCameraTask")

    def setFirstPersonView(self):
        self.taskMgr.remove('spinCameraTask')
        self.taskMgr.remove('followCameraTask')
        self.taskMgr.add(self.cameraControl.first_person_view_task, "firstPersonViewTask")

    def toggle_shadows(self, enable):
        if hasattr(self.spotlight.node(), "setShadowCaster"):
            self.spotlight.node().setShadowCaster(enable)

    # --- Audio / OpenAL ---
    def init_audio(self):
        # Background music
        music_path = "GameMusicLoop.wav"
        self.music = None
        if os.path.exists(music_path):
            self.music = self.loader.loadMusic(music_path)
            if self.music:
                self.music.setLoop(True)
                self.music.setVolume(0.6)
                self.music.play()
        else:
            print(f"[Audio] Music file not found: {music_path}")

        # Sound effects
        sfx_path = "assets/jump.wav"
        self.jumpSound = None
        if os.path.exists(sfx_path):
            self.jumpSound = self.loader.loadSfx(sfx_path)
        else:
            print(f"[Audio] SFX file not found: {sfx_path}")

        # Input to trigger SFX
        self.accept("space", self.play_jump_sound)

        # Music cue task (optional)
        self.taskMgr.add(self.check_music_time, "MusicCueTask")

        print("OpenAL Audio System initialized.")

    def play_jump_sound(self):
        if self.jumpSound:
            self.jumpSound.setVolume(1.0)
            self.jumpSound.play()

    def check_music_time(self, task):
        if self.music:
            current_time = self.music.getTime()
            if current_time > 60.0:
                self.music.setTime(10.0)
        return Task.cont


# Run the application
if __name__ == "__main__":
    app = MyApp()
    app.run()
