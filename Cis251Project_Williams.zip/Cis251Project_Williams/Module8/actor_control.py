from panda3d.core import (
    Point3, CollisionNode, CollisionBox, CollisionSphere, CollisionTraverser,
    CollisionHandlerEvent, DirectionalLight
)
from direct.actor.Actor import Actor
from direct.interval.IntervalGlobal import Sequence, LerpColorScaleInterval
from panda3d.core import NodePath


class ActorControl:
    def __init__(self, base, render, score_callback=None):
        self.base = base
        self.score_callback = score_callback
        self.score = 0
        self.is_in_box = False

        # Load the Panda actor
        self.pandaActor = Actor("models/panda-model", {"walk": "models/panda-walk4"})
        self.pandaActor.setScale(0.005)
        self.pandaActor.reparentTo(render)
        self.pandaActor.loop("walk")

        # Collision system
        self.collision_traverser = CollisionTraverser()
        self.collision_handler = CollisionHandlerEvent()
        self.collision_handler.addInPattern('%fn-into-%in')
        self.collision_handler.addOutPattern('%fn-out-%in')

        # Create collision box and panda collider
        self.create_collision_box(render)
        self.create_panda_collision(render)

        # Lighting
        self.create_lights(render)

        # Movement
        self.create_panda_movement()

        # Event bindings
        self.base.accept("pandaCollider-into-pandaBox", self.on_enter_box)
        self.base.accept("pandaCollider-out-pandaBox", self.on_exit_box)

    def create_collision_box(self, render):
        # Collision box
        collision_node = CollisionNode("pandaBox")
        collision_node.addSolid(CollisionBox(Point3(-2, -2, -2), Point3(2, 2, 2)))
        collision_node.setFromCollideMask(0x0)
        collision_node.setIntoCollideMask(0x1)
        self.box_node = render.attachNewNode(collision_node)
        self.box_node.setPos(0, 0, 0)

        # Visible box
        self.visible_box = render.attachNewNode("visibleBox")
        self.visible_box.setPos(0, 0, 0)
        cube = loader.loadModel("models/box")
        cube.setScale(4)
        cube.reparentTo(self.visible_box)

    def create_panda_collision(self, render):
        panda_collision_node = CollisionNode("pandaCollider")
        panda_collision_node.addSolid(CollisionSphere(0, 0, 0, 1))
        panda_collision_node.setFromCollideMask(0x1)
        panda_collision_node.setIntoCollideMask(0x0)
        panda_collision_path = self.pandaActor.attachNewNode(panda_collision_node)
        self.collision_traverser.addCollider(panda_collision_path, self.collision_handler)

    def create_lights(self, render):
        self.directional_light = DirectionalLight('directionalLight')
        self.directional_light.setColor((1, 1, 1, 1))
        self.directional_light_node = render.attachNewNode(self.directional_light)
        self.directional_light_node.setHpr(0, -60, 0)
        render.setLight(self.directional_light_node)

    def create_panda_movement(self):
        pos1 = self.pandaActor.posInterval(13, Point3(0, -10, 0), startPos=Point3(0, 10, 0))
        pos2 = self.pandaActor.posInterval(13, Point3(0, 10, 0), startPos=Point3(0, -10, 0))
        hpr1 = self.pandaActor.hprInterval(3, Point3(180, 0, 0), startHpr=Point3(0, 0, 0))
        hpr2 = self.pandaActor.hprInterval(3, Point3(0, 0, 0), startHpr=Point3(180, 0, 0))
        self.pandaPace = Sequence(pos1, hpr1, pos2, hpr2, name="pandaPace")
        self.pandaPace.loop()

    def on_enter_box(self, entry):
        self.turn_off_lights(entry)
        self.increment_score(entry)

    def on_exit_box(self, entry):
        self.turn_on_lights(entry)

    def turn_off_lights(self, entry):
        self.directional_light.setColor((0, 0, 0, 1))
        print("Lights turned off.")

    def turn_on_lights(self, entry):
        self.directional_light.setColor((1, 1, 1, 1))
        print("Lights turned on.")

    def increment_score(self, entry):
        self.score += 1
        if self.score_callback:
            self.score_callback(self.score)

        # Play celebratory sound
        if hasattr(self.base, "play_jump_sound"):
            self.base.play_jump_sound()

        # Flash the box
        if hasattr(self, "visible_box"):
            flash = LerpColorScaleInterval(self.visible_box, 0.2, (2, 2, 0, 1), startColorScale=(1, 1, 1, 1))
            unflash = LerpColorScaleInterval(self.visible_box, 0.2, (1, 1, 1, 1), startColorScale=(2, 2, 0, 1))
            Sequence(flash, unflash).start()

    def reset_panda(self):
        self.pandaPace.finish()
        self.pandaActor.setPos(0, 10, 0)
        self.pandaActor.setHpr(0, 0, 0)
        self.pandaActor.stop()
        self.pandaActor.loop("walk")
        self.create_panda_movement()
        self.score = 0
        if self.score_callback:
            self.score_callback(self.score)

    def start_animation(self):
        if not self.pandaActor.getCurrentAnim():
            self.pandaActor.loop("walk")

    def stop_animation(self):
        self.pandaActor.stop()
