# camera.py
import math
from panda3d.core import Point3
from direct.task import Task

class CameraControl:
    def __init__(self, base, actor):
        self.base = base
        self.actor = actor

    def spin_camera_task(self, task):
        angleDegrees = task.time * 6.0
        angleRadians = math.radians(angleDegrees)
        self.base.camera.setPos(30 * math.sin(angleRadians), -30 * math.cos(angleRadians), 6)
        self.base.camera.lookAt(self.actor)
        return Task.cont

    def follow_camera_task(self, task):
        self.base.camera.setPos(self.actor.getPos() + Point3(0, -10, 3))
        self.base.camera.lookAt(self.actor)
        return Task.cont

    def first_person_view_task(self, task):
        self.base.camera.setPos(self.actor.getPos() + Point3(0, 1, 3))
        self.base.camera.lookAt(self.actor.getPos() + Point3(0, 5, 2))
        return Task.cont
