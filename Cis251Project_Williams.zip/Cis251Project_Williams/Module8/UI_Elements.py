from direct.gui.DirectGui import DirectSlider, DirectButton, DirectLabel, DirectFrame
from panda3d.core import TextNode

class UserInterface:
    def __init__(self, base, spotlight, directionalLight, toggle_shadow_callback, reset_callback=None, quit_callback=None):
        self.base = base
        self.spotlight = spotlight
        self.directionalLight = directionalLight
        self.toggle_shadow_callback = toggle_shadow_callback
        self.reset_callback = reset_callback
        self.quit_callback = quit_callback

        # More visible, moved down and left
        self.frame = DirectFrame(
            frameColor=(0.07, 0.13, 0.2, 0.8),  # more opaque and blueish
            frameSize=(-0.8, 0.7, -0.45, 0.4),
            pos=(-1.1, 0, -0.7)
        )

        # Spotlight cone size slider
        self.spotlight_label = DirectLabel(
            text="Spotlight Cone Size (FOV)",
            scale=0.045, pos=(-0.65, 0, 0.32), frameColor=(0,0,0,0),
            parent=self.frame, text_align=TextNode.ALeft
        )
        self.spotlight_slider = DirectSlider(
            range=(5, 60), value=16,
            pageSize=1, scale=0.37, pos=(0.05, 0, 0.32),
            command=self.update_spotlight_fov, parent=self.frame
        )

        # Shadow toggle button
        self.shadow_label = DirectLabel(
            text="Toggle Shadows",
            scale=0.045, pos=(-0.65, 0, 0.18), frameColor=(0,0,0,0),
            parent=self.frame, text_align=TextNode.ALeft
        )
        self.shadow_button = DirectButton(
            text="Shadows OFF", scale=0.065, pos=(0.05, 0, 0.18),
            command=self.toggle_shadows, parent=self.frame
        )
        self.shadows_on = False

        # Directional light brightness slider
        self.dirlight_label = DirectLabel(
            text="Directional Light Brightness",
            scale=0.045, pos=(-0.65,0,0.04), frameColor=(0,0,0,0),
            parent=self.frame, text_align=TextNode.ALeft
        )
        self.dirlight_slider = DirectSlider(
            range=(0, 1), value=0.35,
            pageSize=0.01, scale=0.37, pos=(0.05, 0, 0.04),
            command=self.update_dirlight_brightness, parent=self.frame
        )

        # Reset button
        self.reset_button = DirectButton(
            text="Reset Panda", scale=0.06, pos=(-0.3, 0, -0.15),
            command=self.on_reset, parent=self.frame
        )

        # Quit button
        self.quit_button = DirectButton(
            text="Quit", scale=0.06, pos=(0.25, 0, -0.15),
            command=self.on_quit, parent=self.frame
        )

    def update_spotlight_fov(self):
        fov = self.spotlight_slider['value']
        self.spotlight.node().getLens().setFov(fov, fov)

    def toggle_shadows(self):
        self.shadows_on = not self.shadows_on
        if self.shadows_on:
            self.shadow_button['text'] = "Shadows ON"
        else:
            self.shadow_button['text'] = "Shadows OFF"
        self.toggle_shadow_callback(self.shadows_on)

    def update_dirlight_brightness(self):
        bright = self.dirlight_slider['value']
        color = (bright, bright, bright, 1)
        self.directionalLight.node().setColor(color)

    def on_reset(self):
        if self.reset_callback:
            self.reset_callback()

    def on_quit(self):
        if self.quit_callback:
            self.quit_callback()
