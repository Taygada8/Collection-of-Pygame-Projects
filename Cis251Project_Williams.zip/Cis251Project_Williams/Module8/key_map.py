# key_map.py
class KeyMap:
    def __init__(self):
        self.key_map = {
            "startAnimation": False,
            "stopAnimation": False,
        }

    def set_key(self, key, value):
        self.key_map[key] = value

    def get_key(self, key):
        return self.key_map.get(key, False)
